from abc import ABC, abstractmethod
import pandas as pd

class DataProvider(ABC):
    @abstractmethod
    def get_ohlc(self, symbol, timeframe='1h', start=None, end=None, limit=500):
        ...
