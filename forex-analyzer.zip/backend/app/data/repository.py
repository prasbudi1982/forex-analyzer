from app.data.providers.twelvedata import TwelveDataProvider

_provider = TwelveDataProvider()

def get_ohlc(symbol, timeframe='1h', limit=500):
    return _provider.get_ohlc(symbol, timeframe, limit=limit)
