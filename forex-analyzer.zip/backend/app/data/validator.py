import pandas as pd

def validate_ohlc(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    df = df.drop_duplicates(subset=['datetime']).sort_values('datetime')
    df = df[df['high'] >= df['low']]
    return df.reset_index(drop=True)
