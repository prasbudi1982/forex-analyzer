from fastapi import APIRouter
from .routes_market import router as market_router

api_router = APIRouter()
api_router.include_router(market_router, prefix='/market', tags=['market'])
