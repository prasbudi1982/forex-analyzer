def ema(df, period=20):
    return df['close'].ewm(span=period, adjust=False).mean()

def sma(df, period=20):
    return df['close'].rolling(period).mean()
