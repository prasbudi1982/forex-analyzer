from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    APP_NAME: str = 'forex-analyzer'
    CORS_ORIGINS: list[str] = ['http://localhost:3000']
    DATA_DIR: str = './data/ohlc'
    TWELVEDATA_API_KEY: str = ''
    OANDA_API_KEY: str = ''
    OANDA_ACCOUNT_ID: str = ''
    REDIS_URL: str = 'redis://localhost:6379/0'

    class Config:
        env_file = '.env'

settings = Settings()
